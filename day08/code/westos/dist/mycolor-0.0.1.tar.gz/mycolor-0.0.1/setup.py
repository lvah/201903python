from distutils.core import setup

setup(
    name='mycolor',
    version='0.0.1',
    author='lvah',
    author_email='976131979@qq.com',
    url='http://www.baidu.com',
    description="颜色字体显示",
    py_modules=['mycolor', 'other']
)
