# 当导入模块， 实际执行了模块的代码
import  mycolor


mycolor.red()
mycolor.blue()


